--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "1101_db_76";
--
-- Name: 1101_db_76; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "1101_db_76" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Chinese (Traditional)_Taiwan.950';


ALTER DATABASE "1101_db_76" OWNER TO postgres;

\connect "1101_db_76"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: midproj_76; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.midproj_76 (
    id integer NOT NULL,
    name character varying,
    length character varying,
    remote_url character varying,
    local_url character varying
);


ALTER TABLE public.midproj_76 OWNER TO postgres;

--
-- Data for Name: midproj_76; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.midproj_76 (id, name, length, remote_url, local_url) FROM stdin;
\.
COPY public.midproj_76 (id, name, length, remote_url, local_url) FROM '$$PATH$$/2988.dat';

--
-- Name: midproj_76 midproj_76_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.midproj_76
    ADD CONSTRAINT midproj_76_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

